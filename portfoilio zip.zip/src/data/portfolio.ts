// Interfaces

export interface Project {
  id: string;
  title: string;
  description: string;
  techStack: string[];
  githubLink?: string;
  liveDemo?: string;
  image: string;
  video?: string;
}

export interface Experience {
  id: string;
  role: string;
  company: string;
  duration: string;
  description: string;
}

export interface Skill {
  id: string;
  category: 'Frontend' | 'Backend' | 'Database' | 'Tools';
  name: string;
  icon?: string;
  proficiency?: number;
}

export interface Achievement {
  id: string | number;
  title: string;
  description: string;
  icon: string;
}

// ================= PROJECTS =================

export const projects: Project[] = [
  {
    id: 'p1',
    title: 'Hariss International - Laravel Backend System',
    description:
      'Built scalable REST APIs with authentication (Sanctum & Passport), RBAC using Spatie, and optimized database queries for performance.',
    techStack: ['Laravel', 'PHP', 'MySQL', 'REST API', 'Sanctum', 'Spatie'],
    githubLink: 'https://github.com/your-username/hariss-backend',
    image: 'https://images.unsplash.com/photo-1555066931-4365d14bab8c?w=800&q=80',
  },
  {
    id: 'p2',
    title: 'CookingStories - Recipe Platform',
    description:
      'Developed full-stack Django application with CRUD operations, dynamic filtering, and responsive UI using Tailwind CSS.',
    techStack: ['Django', 'Python', 'SQLite', 'Tailwind CSS'],
    githubLink: 'https://github.com/your-username/cookingstories',
    image: 'https://images.unsplash.com/photo-1495521821757-a1efb6729352?w=800&q=80',
  },
  {
    id: 'p3',
    title: 'REST API System',
    description:
      'Designed robust API architecture with validation, centralized error handling, and PostgreSQL query optimization.',
    techStack: ['Laravel', 'PostgreSQL', 'API Development', 'Postman'],
    githubLink: 'https://github.com/your-username/api-system',
    image: 'https://images.unsplash.com/photo-1558494949-ef010cbdcc31?w=800&q=80',
  }
];

// ================= EXPERIENCE =================

export const experiences: Experience[] = [
  {
    id: '1',
    role: 'Software Developer',
    company: 'TechnoBren Infotech Pvt. Ltd.',
    duration: 'Mar 2025 - Present',
    description:
      'Building scalable backend systems using Laravel, developing REST APIs, implementing authentication & RBAC, and optimizing database performance using Eloquent ORM.'
  },
  {
    id: '2',
    role: 'Software Developer Intern',
    company: 'Digipodium',
    duration: 'Jun 2024 - Sep 2024',
    description:
      'Worked on frontend and backend using HTML, CSS, JavaScript, React, and Python while improving UI responsiveness and application performance.'
  }
];

// ================= SKILLS =================

export const skills: Skill[] = [
  // Backend
  { id: 's1', category: 'Backend', name: 'Laravel', icon: '🔥', proficiency: 90 },
  { id: 's2', category: 'Backend', name: 'Django', icon: '🐍', proficiency: 80 },
  { id: 's3', category: 'Backend', name: 'REST APIs', icon: '🔗', proficiency: 90 },
  { id: 's4', category: 'Backend', name: 'Auth & RBAC', icon: '🔐', proficiency: 85 },

  // Database
  { id: 's5', category: 'Database', name: 'MySQL', icon: '🗄️', proficiency: 85 },
  { id: 's6', category: 'Database', name: 'PostgreSQL', icon: '🐘', proficiency: 80 },
  { id: 's7', category: 'Database', name: 'Query Optimization', icon: '⚡', proficiency: 75 },

  // Frontend
  { id: 's8', category: 'Frontend', name: 'HTML', icon: '🌐', proficiency: 85 },
  { id: 's9', category: 'Frontend', name: 'CSS', icon: '🎨', proficiency: 80 },
  { id: 's10', category: 'Frontend', name: 'Tailwind CSS', icon: '💨', proficiency: 85 },
  { id: 's11', category: 'Frontend', name: 'Bootstrap', icon: '📦', proficiency: 80 },

  // Tools
  { id: 's12', category: 'Tools', name: 'Postman', icon: '📮', proficiency: 85 },
  { id: 's13', category: 'Tools', name: 'Git & GitHub', icon: '🐙', proficiency: 80 },
];

// ================= ACHIEVEMENTS =================

export const achievements: Achievement[] = [
  {
    id: 1,
    title: 'Backend Expertise',
    description: 'Built scalable backend systems and APIs using Laravel & Django',
    icon: '⚙️'
  },
  {
    id: 2,
    title: 'Industry Experience',
    description: 'Working as Software Developer at TechnoBren Infotech',
    icon: '💼'
  },
  {
    id: 3,
    title: 'Full Stack Projects',
    description: 'Developed multiple real-world applications with complete functionality',
    icon: '🚀'
  }
];